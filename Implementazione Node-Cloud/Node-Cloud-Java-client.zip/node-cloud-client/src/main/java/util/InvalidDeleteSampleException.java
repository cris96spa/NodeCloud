package util;

public class InvalidDeleteSampleException extends Exception {
	public InvalidDeleteSampleException(String message) {
		super(message);
	}

}
