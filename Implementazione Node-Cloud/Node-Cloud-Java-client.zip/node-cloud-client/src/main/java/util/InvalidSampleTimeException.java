package util;

public class InvalidSampleTimeException extends Exception {
	public InvalidSampleTimeException(String message) {
		super(message);
	}
}
