package util;

public class InvalidWindowException extends Exception {
	
	public InvalidWindowException(String message) {
		super(message);
	}
}
