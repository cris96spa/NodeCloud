package util;

public class InvalidContextException extends Exception {
	public InvalidContextException(String message) {
		super(message);
	}

}
