package util;

public class InvalidSampleException extends Exception {

	public InvalidSampleException(String message) {
		super(message);
	}
}
