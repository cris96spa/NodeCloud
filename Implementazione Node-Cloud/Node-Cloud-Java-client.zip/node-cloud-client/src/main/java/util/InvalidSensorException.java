package util;

public class InvalidSensorException extends Exception {
	public InvalidSensorException(String message) {
		super(message);
	}

}
